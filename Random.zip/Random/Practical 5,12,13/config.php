<?php

$databaseName='pol';
$databaseHost='localhost';
$databaseUsername='root';
$databasePassword='';

$mysqli=mysqli_connect($databaseHost,$databaseUsername,$databasePassword,$databaseName);

?>