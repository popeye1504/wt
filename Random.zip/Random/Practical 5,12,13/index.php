<?php
	include_once("config.php");
	
	$result=mysqli_query($mysqli,"SELECT * FROM lopo");
?>

<html>
<head>
	<title>Home</title>
</head>

<body>
	<a href="add.html">ADD DATA</a>
	<table border="1.0">
	<tr>
	<td>ID</td>
	<td>Name</td>
	<td>Mail</td>
	<td>Phone</td>
	</tr>
<?php
	while($res=mysqli_fetch_array($result))
	{
	echo"<tr>";
	echo"<td>".$res['id']."</td>";
	echo"<td>".$res['name']."</td>";
	echo"<td>".$res['mail']."</td>";
	echo"<td>".$res['phone']."</td>";	
	echo"<td><a href=\"edit.php?id=$res[id]\">edit</a> | <a href=\"delete.php?id=$res[id]\">Delete</a></td>";
	echo"</tr>";
	}
?>
</table>
</body>
</html>