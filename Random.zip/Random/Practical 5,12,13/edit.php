<?php

	include_once("config.php");
	$id=$_GET['id'];
	$result=mysqli_query($mysqli,"SELECT * FROM lopo where id=$id");
	while($res=mysqli_fetch_array($result))
	{
	$id=$res['id'];	
	$name=$res['name'];
	$mail=$res['mail'];
	$phone=$res['phone'];
	}
?>

<html>
<head
	<title>Edit data</title>
</head>
<body>
<a href="index.php">Home</a>
<form action="" method="POST">
		
		<br><h2> Name</h2><input type ="text" name="name" value="" ><br>
		<br><h2> Email id</h2><input type ="email" name="mail" value="" ><br>
		<br><h2> Phone </h2><input type ="number" name="phone" value="" ><br>
		<br><h2> Rollno</h2><input type ="number" name="id" value="" ><br>
		<br> <input type ="submit" name="submit" value="submit"> <br>	
	</form>
<?php
	
	if(isset($_POST['submit']))
	{
	$nid=$_POST['id'];
	$nname=$_POST['name'];
	$nmail=$_POST['mail'];
	$nphone=$_POST['phone'];
	
	
	$result=mysqli_query($mysqli,"UPDATE lopo SET id='$nid',name='$nname',mail='$nmail',phone='$nphone' WHERE id=$id");
	echo"Data Edited Succesfully";
	echo"<a href='index.php'>Home</a>";
	

	}
?>
</body>
</html>