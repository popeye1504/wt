<html>
<head
	<title>Add data</title>
</head>
<body>
<?php
	include_once("config.php");
	
	if(isset($_POST['submit']))
	{
	$id=$_POST['id'];
	$name=$_POST['name'];
	$mail=$_POST['mail'];
	$phone=$_POST['phone'];
	
	if(empty($id) || empty($name) || empty($mail) || empty($phone))
	{
	echo "Invalid"	;
	}
	else
	{
	$result=mysqli_query($mysqli,"INSERT INTO lopo(id,name,mail,phone) VALUES ('$id','$name','$mail','$phone')");
	echo"Data Added Succesfully";
	echo"<a href='index.php'>Home</a>";
	}

	}
?>
</body>
</html>