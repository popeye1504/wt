<?php
include_once("config.php");
$id=$_GET['id'];
$res=mysqli_query($mysqli,"DELETE FROM lopo WHERE id=$id");
echo "<a href='index.php'>Home</a>";
?>